//
//  ApplyForViewController.h
//  YiYiProject
//
//  Created by soulnear on 14-12-21.
//  Copyright (c) 2014年 lcw. All rights reserved.
//
/*
 申请搭配师
 */

#import <UIKit/UIKit.h>

@interface ApplyForViewController : MyViewController
{
    
}






@end
