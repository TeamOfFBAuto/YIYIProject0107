//
//  GupLogClothesViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/6/27.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

/**
 *  买衣日志 上传衣服
 */

#import "MyViewController.h"

@interface GupLogClothesViewController : MyViewController

@end
