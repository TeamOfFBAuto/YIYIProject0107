//
//  GTtaiRelationStoreModel.m
//  YiYiProject
//
//  Created by gaomeng on 15/8/24.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "GTtaiRelationStoreModel.h"

@implementation GTtaiRelationStoreModel

@end
