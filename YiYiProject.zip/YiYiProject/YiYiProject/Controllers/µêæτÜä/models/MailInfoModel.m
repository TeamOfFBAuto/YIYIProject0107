//
//  MailInfoModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/22.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MailInfoModel.h"

@implementation MailInfoModel

@end
