//
//  YiChuListModel.h
//  YiYiProject
//
//  Created by szk on 14/12/28.
//  Copyright (c) 2014年 lcw. All rights reserved.
//


//衣橱分类列表衣服的model
#import <Foundation/Foundation.h>

@interface YiChuListModel : NSObject


@property(nonatomic,strong)NSString *clothesID;

//@property(nonatomic,strong)NSString *clothesID;
//
//@property(nonatomic,strong)NSString *clothesID;
//
//@property(nonatomic,strong)NSString *clothesID;


@end
