//
//  GMoreTtaiSameStroViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/8/26.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

@interface GMoreTtaiSameStroViewController : MyViewController


@property(nonatomic,strong)NSDictionary *locationDic;//位置信息
@property(nonatomic,strong)NSString *tPlat_id;//T台id


@end
