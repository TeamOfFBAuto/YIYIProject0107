//
//  CouponModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/9/10.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "CouponModel.h"

@implementation CouponModel

@end
