//
//  WaterFallFooter.m
//  CollectionView
//
//  Created by d2space on 14-2-27.
//  Copyright (c) 2014年 D2space. All rights reserved.
//

#import "WaterFallFooter.h"

@implementation WaterFallFooter

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blueColor];
    }
    return self;
}

@end
