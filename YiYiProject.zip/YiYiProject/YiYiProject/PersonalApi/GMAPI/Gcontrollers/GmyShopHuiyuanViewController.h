//
//  GmyShopHuiyuanViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/4/16.
//  Copyright (c) 2015年 lcw. All rights reserved.
//



//店铺会员 收藏我的店铺的人

#import <UIKit/UIKit.h>
#import "MailInfoModel.h"

@interface GmyShopHuiyuanViewController : MyViewController


@property(nonatomic,strong)MailInfoModel *mallInfo;//店铺信息

@end
