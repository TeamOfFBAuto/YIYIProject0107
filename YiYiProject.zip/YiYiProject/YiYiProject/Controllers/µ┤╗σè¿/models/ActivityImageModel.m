//
//  ActivityImageModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/6/2.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ActivityImageModel.h"

@implementation ActivityImageModel

@end
