//
//  main.msadasdas
//  YiYiProject
//
//  Created by lichaowei on 14/12/10.dsa
//  Copyright (c) 2014年 lcw. All rights reserved.
//xx

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
 
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

