//
//  BrandModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/4.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "BrandModel.h"

@implementation BrandModel

@end
