//
//  GBuyClothLogModel.m
//  YiYiProject
//
//  Created by gaomeng on 15/6/27.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "GBuyClothLogModel.h"

@implementation GBuyClothLogModel


@end
