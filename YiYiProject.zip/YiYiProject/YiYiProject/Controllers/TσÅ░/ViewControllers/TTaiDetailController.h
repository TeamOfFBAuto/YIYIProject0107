//
//  TTaiDetailController.h
//  YiYiProject
//
//  Created by lichaowei on 15/1/6.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

/**
 *  T台详情
 */
@interface TTaiDetailController : MyViewController

@property(nonatomic,retain)NSString *tt_id;//t台id

@end
