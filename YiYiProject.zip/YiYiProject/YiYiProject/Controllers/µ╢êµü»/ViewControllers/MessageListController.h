//
//  MessageListController.h
//  YiYiProject
//
//  Created by lichaowei on 15/1/25.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

/**
 *  消息列表
 */
@interface MessageListController : MyViewController

@end
