//
//  MatchInfoViewController.h
//  YiYiProject
//
//  Created by soulnear on 14-12-28.
//  Copyright (c) 2014年 lcw. All rights reserved.
//
/*
 搭配师主页
 */

#import <UIKit/UIKit.h>

@interface MatchInfoViewController : UIViewController
{
    
}

///搭配师uid
@property(nonatomic,strong)NSString * match_uid;

@end
