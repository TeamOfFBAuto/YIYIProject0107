//
//  GmaodianModel.h
//  YiYiProject
//
//  Created by gaomeng on 15/5/19.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GmaodianModel : BaseModel


@property(nonatomic,strong)NSString *tt_img_info_id;
@property(nonatomic,strong)NSString *tt_id;
@property(nonatomic,strong)NSString *tt_img_id;
@property(nonatomic,strong)NSString *img_x;
@property(nonatomic,strong)NSString *img_y;
@property(nonatomic,strong)NSString *shop_id;
@property(nonatomic,strong)NSString *product_id;
@property(nonatomic,strong)NSString *dateline;
@property(nonatomic,strong)NSString *shop_name;
@property(nonatomic,strong)NSString *product_name;

@end
