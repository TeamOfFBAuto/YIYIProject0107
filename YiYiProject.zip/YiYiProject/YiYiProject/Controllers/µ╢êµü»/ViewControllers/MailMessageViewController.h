//
//  MailMessageViewController.h
//  YiYiProject
//
//  Created by lichaowei on 15/1/14.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

/**
 *  具体消息列表
 */
@interface MailMessageViewController : MyViewController

@property(nonatomic,assign)Message_List_Type aType;

@end
    