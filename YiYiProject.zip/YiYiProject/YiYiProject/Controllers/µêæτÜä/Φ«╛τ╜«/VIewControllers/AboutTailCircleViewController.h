//
//  AboutTailCircleViewController.h
//  TailCircle
//
//  Created by 王龙 on 14/12/19.
//  Copyright (c) 2014年 王龙. All rights reserved.
//


@interface AboutTailCircleViewController : MyViewController
@property (strong, nonatomic) IBOutlet UILabel *versionLabel; //版本号
@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;

@end
