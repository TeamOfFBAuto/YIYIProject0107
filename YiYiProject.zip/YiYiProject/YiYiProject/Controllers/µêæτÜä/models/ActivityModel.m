//
//  ActivityModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/21.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ActivityModel.h"

@implementation ActivityModel

@end
