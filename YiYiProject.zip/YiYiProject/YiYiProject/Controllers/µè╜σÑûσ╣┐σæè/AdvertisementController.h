//
//  AdvertisementController.h
//  YiYiProject
//
//  Created by lichaowei on 15/6/26.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"
/**
 *  广告 或者 抽奖
 */
@interface AdvertisementController : MyViewController

@property(nonatomic,retain)NSString *targetUrl;//目标地址
@property(nonatomic,retain)NSString *targetTitle;

@end
