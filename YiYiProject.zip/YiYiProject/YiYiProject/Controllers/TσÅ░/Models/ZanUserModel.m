//
//  ZanUserModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/5/5.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ZanUserModel.h"

@implementation ZanUserModel

@end
