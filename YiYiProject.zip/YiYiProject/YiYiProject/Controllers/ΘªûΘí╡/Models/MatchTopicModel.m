//
//  MatchTopicModel.m
//  YiYiProject
//
//  Created by soulnear on 14-12-20.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import "MatchTopicModel.h"

@implementation MatchTopicModel

@end
