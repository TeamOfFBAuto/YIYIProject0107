//
//  GBuyClothesLogViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/6/27.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


/**
 *  买衣日志
 */

#import <UIKit/UIKit.h>

@interface GBuyClothesLogViewController : MyViewController


@end
