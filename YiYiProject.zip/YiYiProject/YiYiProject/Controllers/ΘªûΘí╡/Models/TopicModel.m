//
//  TopicModel.m
//  YiYiProject
//
//  Created by soulnear on 15-1-4.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "TopicModel.h"

@implementation TopicModel

@end
