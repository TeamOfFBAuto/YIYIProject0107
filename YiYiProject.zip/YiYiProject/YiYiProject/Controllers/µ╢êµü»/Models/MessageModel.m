//
//  MessageModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/17.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel

@end
