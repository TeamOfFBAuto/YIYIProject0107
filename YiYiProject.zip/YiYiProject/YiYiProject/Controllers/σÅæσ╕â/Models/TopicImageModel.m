//
//  TopicImageModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "TopicImageModel.h"

@implementation TopicImageModel

@end
