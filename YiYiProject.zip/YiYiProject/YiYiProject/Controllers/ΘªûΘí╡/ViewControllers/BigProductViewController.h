//
//  BigProductViewController.h
//  YiYiProject
//
//  Created by lichaowei on 15/6/9.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"
/**
 *  单品的大图模式
 */
@interface BigProductViewController : MyViewController

@property(nonatomic,assign)UIViewController *rootViewController;

@end
