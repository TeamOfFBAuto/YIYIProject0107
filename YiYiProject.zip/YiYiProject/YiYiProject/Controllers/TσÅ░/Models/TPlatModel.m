//
//  TPlatModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/1/2.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "TPlatModel.h"

@implementation TPlatModel

@end
