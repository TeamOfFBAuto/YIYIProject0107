//
//  TopicDetailViewController.h
//  YiYiProject
//
//  Created by soulnear on 14-12-27.
//  Copyright (c) 2014年 lcw. All rights reserved.
//
/*
 话题详情界面
 */
#import <UIKit/UIKit.h>
#import "MatchTopicModel.h"

@interface TopicDetailViewController : MyViewController
{
    
}



@property(nonatomic,strong)MatchTopicModel * topic_model;

@end
