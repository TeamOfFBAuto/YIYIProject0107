//
//  GfangkeViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/5/11.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


//我的访客

#import "MyViewController.h"

@interface GfangkeViewController : MyViewController


@property(nonatomic,strong)NSString *shop_id;

@end
