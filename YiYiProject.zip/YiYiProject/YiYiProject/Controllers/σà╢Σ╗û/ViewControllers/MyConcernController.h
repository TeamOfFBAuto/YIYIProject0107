//
//  MyConcernController.h
//  YiYiProject
//
//  Created by lichaowei on 15/1/2.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"
/**
 *  我的收藏
 */
@interface MyConcernController : MyViewController

@property(nonatomic,retain)NSString *uid;

@end
