//
//  GShopPhoneViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/4/17.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GShopPhoneViewController : MyViewController


@property(nonatomic,strong)NSString *shop_id;

@property(nonatomic,strong)NSString *theShopPhone;//店铺电话

@end
