//
//  GMapShowMyshopViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/4/17.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GMapShowMyshopViewController : MyViewController


@property(nonatomic,assign)CLLocationCoordinate2D coordinate_store;//店铺坐标

@property(nonatomic,strong)NSString *storeName;//店铺名字

@end
