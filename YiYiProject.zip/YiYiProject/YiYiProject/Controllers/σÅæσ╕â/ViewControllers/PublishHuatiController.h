//
//  PublishHuatiController.h
//  YiYiProject
//
//  Created by lichaowei on 14/12/28.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import "MyViewController.h"
/**
 *  发布话题
 */
@interface PublishHuatiController : MyViewController

@end
