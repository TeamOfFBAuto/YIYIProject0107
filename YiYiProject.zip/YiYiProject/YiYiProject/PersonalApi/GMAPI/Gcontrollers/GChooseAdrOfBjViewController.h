//
//  GChooseAdrOfBjViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/9/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

//选择地区

#import "MyViewController.h"

@interface GChooseAdrOfBjViewController : MyViewController

@end
