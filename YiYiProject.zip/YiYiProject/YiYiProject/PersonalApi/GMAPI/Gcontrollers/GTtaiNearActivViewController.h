//
//  GTtaiNearActivViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/8/14.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


//T台列表里点击附近的活动

#import "MyViewController.h"

@interface GTtaiNearActivViewController : MyViewController

@property(nonatomic,strong)NSDictionary *locationDic;

@end
