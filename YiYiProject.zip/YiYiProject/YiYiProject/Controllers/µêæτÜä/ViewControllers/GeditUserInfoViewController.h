//
//  GeditUserInfoViewController.h
//  YiYiProject
//
//  Created by gaomeng on 14/12/13.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GeditUserInfoViewController : UIViewController




@end
