//
//  GmaodianModel.m
//  YiYiProject
//
//  Created by gaomeng on 15/5/19.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "GmaodianModel.h"

@implementation GmaodianModel




@end
