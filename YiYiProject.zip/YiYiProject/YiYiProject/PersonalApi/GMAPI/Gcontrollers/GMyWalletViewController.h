//
//  GMyWalletViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/6/29.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


/**
 *  我的钱包
 */
#import "MyViewController.h"

@interface GMyWalletViewController : MyViewController

@property(nonatomic,strong)NSString *jifen;//我的积分


@end
