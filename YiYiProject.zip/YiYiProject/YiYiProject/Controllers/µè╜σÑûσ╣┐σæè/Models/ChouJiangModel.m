//
//  ChouJiangModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/6/29.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ChouJiangModel.h"
//#import <objc/runtime.h>

@implementation ChouJiangModel

@end
