//
//  NSString+Addtions.h
//  YiYiProject
//
//  Created by lichaowei on 15/6/11.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Addtions)

/**
 *  去掉末尾 .0
 *
 *  @return
 */
- (NSString *)stringByRemoveTrailZero;

@end
