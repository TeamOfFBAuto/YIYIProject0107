//
//  GchatSettingViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/3/27.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCChatSettingViewController.h"

@interface GchatSettingViewController : RCChatSettingViewController

@end
