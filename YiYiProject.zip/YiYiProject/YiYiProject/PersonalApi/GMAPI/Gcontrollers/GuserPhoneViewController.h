//
//  GuserPhoneViewController.h
//  YiYiProject
//
//  Created by gaomeng on 15/4/17.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

//用户绑定手机号

#import <UIKit/UIKit.h>

@interface GuserPhoneViewController : MyViewController



@end
