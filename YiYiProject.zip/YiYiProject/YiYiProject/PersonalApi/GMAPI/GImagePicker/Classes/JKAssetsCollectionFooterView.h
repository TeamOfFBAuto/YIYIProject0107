//
//  JKAssetsCollectionFooterView.h
//  JKImagePicker
//
//  Created by Jecky on 15/1/12.
//  Copyright (c) 2015年 Jecky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKAssetsCollectionFooterView : UICollectionReusableView

@property (nonatomic, strong) UILabel *textLabel;

@end
