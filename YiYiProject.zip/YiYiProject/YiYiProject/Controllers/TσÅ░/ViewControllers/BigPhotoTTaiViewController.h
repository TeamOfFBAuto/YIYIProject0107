//
//  BigPhotoTTaiViewController.h
//  YiYiProject
//
//  Created by lichaowei on 15/4/20.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


/// 大图模式T台

#import <UIKit/UIKit.h>
@interface BigPhotoTTaiViewController : MyViewController

@end
