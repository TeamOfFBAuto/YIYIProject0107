//
//  HomeViewController.h
//  YiYiProject
//
//  Created by lichaowei on 14/12/10.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import "MyViewController.h"

@interface HomeViewController : MyViewController

@end
