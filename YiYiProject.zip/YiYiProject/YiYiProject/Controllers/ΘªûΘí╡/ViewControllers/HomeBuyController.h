//
//  HomeBuyController.h
//  YiYiProject
//
//  Created by lichaowei on 14/12/12.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  值得买 改 单品 改 大图
 */

@interface HomeBuyController : UIViewController

@property(nonatomic,assign)UIViewController *rootViewController;

@end
