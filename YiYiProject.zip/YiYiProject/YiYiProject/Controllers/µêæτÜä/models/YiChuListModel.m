//
//  YiChuListModel.m
//  YiYiProject
//
//  Created by szk on 14/12/28.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import "YiChuListModel.h"

@implementation YiChuListModel

/*id: "3",
 uid: "25",
 image_url: "http://182.92.158.32:83/wardrobe/201412/549f81e0212ae.jpg",
 sort_id: "3"*/


@end
