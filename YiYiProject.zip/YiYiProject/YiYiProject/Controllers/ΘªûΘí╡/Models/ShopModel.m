//
//  ShopModel.m
//  YiYiProject
//
//  Created by lichaowei on 15/9/11.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

/**
 *  店铺model
 */
#import "ShopModel.h"

@implementation ShopModel

@end
